enum suit {
    DIAMOND,
    SPADE,
    HEART,
    CLUB
};

const char* suit_name[4] = {"DIAMOND", "SPADE", "HEART", "CLUB"};
#include <iostream>

int main () {
    std::cout << suit_name[DIAMOND] << '\n';
    std::cout << suit_name[SPADE] << '\n';
}
